package dev.lyricsplayer.lyrics;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parses common [mm:ss.xx] LRC timestamps. Pure Java; safe to unit-test off-device. */
public final class LrcParser {
    private static final Pattern TIMESTAMP =
            Pattern.compile("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?]");

    private LrcParser() {}

    public static List<LrcLine> parse(String input) {
        List<LrcLine> result = new ArrayList<>();
        for (String raw : input.split("\\R")) {
            Matcher matcher = TIMESTAMP.matcher(raw);
            List<Long> times = new ArrayList<>();
            while (matcher.find()) {
                long minutes = Long.parseLong(matcher.group(1));
                long seconds = Long.parseLong(matcher.group(2));
                String fraction = matcher.group(3);
                long millis = fraction == null ? 0 :
                        Long.parseLong((fraction + "00").substring(0, 3));
                times.add(minutes * 60_000 + seconds * 1_000 + millis);
            }
            String lyric = TIMESTAMP.matcher(raw).replaceAll("").trim();
            if (!lyric.isEmpty()) {
                for (long time : times) result.add(new LrcLine(time, lyric));
            }
        }
        result.sort(Comparator.comparingLong(LrcLine::timeMillis));
        return List.copyOf(result);
    }

    public static int indexAt(List<LrcLine> lines, long positionMillis) {
        int low = 0, high = lines.size() - 1, answer = -1;
        while (low <= high) {
            int mid = (low + high) >>> 1;
            if (lines.get(mid).timeMillis() <= positionMillis) {
                answer = mid;
                low = mid + 1;
            } else high = mid - 1;
        }
        return answer;
    }
}
