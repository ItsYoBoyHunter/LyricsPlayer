package dev.lyricsplayer.lyrics;

public record LrcLine(long timeMillis, String text) {}
