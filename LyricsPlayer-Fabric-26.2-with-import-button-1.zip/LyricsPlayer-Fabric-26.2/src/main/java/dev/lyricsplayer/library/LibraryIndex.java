package dev.lyricsplayer.library;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * Reads a simple properties-based index. The eventual Android-safe client
 * implementation should use Minecraft's resource reload/audio pipeline,
 * not Java Sound or desktop-only media APIs.
 */
public final class LibraryIndex {
    private LibraryIndex() {}

    public static List<Track> read(Path libraryFolder) throws IOException {
        Path index = libraryFolder.resolve("library.properties");
        if (!Files.isRegularFile(index)) return List.of();

        Properties properties = new Properties();
        try (var reader = Files.newBufferedReader(index)) {
            properties.load(reader);
        }

        int count = Integer.parseInt(properties.getProperty("track.count", "0"));
        List<Track> tracks = new ArrayList<>();
        for (int i = 1; i <= count; i++) {
            String prefix = "track." + i + ".";
            String id = properties.getProperty(prefix + "id");
            String title = properties.getProperty(prefix + "title");
            String audio = properties.getProperty(prefix + "audio");
            String lyrics = properties.getProperty(prefix + "lyrics");
            if (id != null && title != null && audio != null && lyrics != null) {
                tracks.add(new Track(id, title, audio, lyrics));
            }
        }
        return List.copyOf(tracks);
    }
}
