package dev.lyricsplayer.library;

public record Track(String id, String title, String audioFile, String lyricsFile) {}
